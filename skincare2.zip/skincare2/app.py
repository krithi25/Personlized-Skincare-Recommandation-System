from flask import Flask, render_template, request, redirect, url_for, send_file
from PIL import Image
import numpy as np
import pandas as pd
import os

# We'll attempt to import the predictor lazily when needed so the running
# server can pick up newly-installed TensorFlow or a newly-saved model
# without requiring a full process restart.
cnn_predict_skin_type = None
_HAS_CNN = False

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

PRODUCT_CSV = os.path.join(os.path.dirname(__file__), 'data', 'products.csv')
EVAL_REPORT = os.path.join(os.path.dirname(__file__), 'models', 'eval_report.txt')
EVAL_IMAGE = os.path.join(os.path.dirname(__file__), 'models', 'confusion_matrix.png')

# --- Simple heuristic skin-type detection from image ---
def detect_skin_type(image_path):
    """
    Lightweight heuristic to infer skin type from a facial crop.
    This is a prototype placeholder — replace with a trained CNN for production.
    Returns one of: 'oily', 'dry', 'normal', 'combination'
    """
    img = Image.open(image_path).convert('RGB')
    # Resize and crop center
    w, h = img.size
    side = int(min(w, h) * 0.6)
    left = (w - side) // 2
    top = (h - side) // 2
    crop = img.crop((left, top, left + side, top + side)).resize((224, 224))
    arr = np.asarray(crop).astype(np.float32)

    # Convert to HSV to inspect brightness/value and saturation
    # Rough heuristic: oily skin often shows higher shine (higher V and low variance across hue),
    # dry skin appears matte (lower V), combination in-between.
    rgb = arr / 255.0
    r, g, b = rgb[...,0], rgb[...,1], rgb[...,2]
    maxc = np.maximum(np.maximum(r, g), b)
    minc = np.minimum(np.minimum(r, g), b)
    v = maxc
    s = (maxc - minc) / (maxc + 1e-6)

    mean_v = float(v.mean())
    mean_s = float(s.mean())
    std_v = float(v.std())

    # Empirical thresholds (prototype):
    if mean_v > 0.65 and std_v < 0.08 and mean_s < 0.25:
        return 'oily'
    if mean_v < 0.45 and mean_s > 0.20:
        return 'dry'
    if 0.45 <= mean_v <= 0.65:
        return 'normal'
    return 'combination'


def contains_face_or_skin(image_path, skin_thresh=0.02):
    """Return True if the image likely contains a face or skin region.

    Strategy:
    - Try OpenCV Haar cascade face detector (if `cv2` installed).
    - If OpenCV not available or no faces found, fall back to a simple
      skin-color proportion test in YCrCb color space.
    """
    try:
        import cv2
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        if os.path.exists(cascade_path):
            img = cv2.imread(image_path)
            if img is None:
                return False
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            face_cascade = cv2.CascadeClassifier(cascade_path)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(30,30))
            if len(faces) > 0:
                return True
        # if cascade missing or no faces found, fall through to color heuristic
    except Exception:
        # OpenCV not available or failed; fall back
        pass

    # Fallback: estimate proportion of skin-colored pixels in YCrCb
    try:
        img = Image.open(image_path).convert('RGB')
        arr = np.asarray(img)
        # convert to YCrCb-like using simple transform
        r = arr[...,0].astype(np.int32)
        g = arr[...,1].astype(np.int32)
        b = arr[...,2].astype(np.int32)
        # Cr and Cb approximations
        cr = 128 + (112 * (r - g) + 38 * (r - b)) // 256
        cb = 128 + (112 * (b - g) + 38 * (b - r)) // 256
        # skin range heuristics (approx)
        mask = (cr > 140) & (cr < 180) & (cb > 100) & (cb < 140)
        proportion = float(mask.sum()) / float(mask.size)
        return proportion >= skin_thresh
    except Exception:
        return False


def detect_skin_type_with_model(image_path):
    """Attempt to predict using trained CNN.

    Returns (label, probs) where probs is a dict mapping class->probability.
    Raises if model not available.
    """
    global cnn_predict_skin_type, _HAS_CNN
    # Try dynamic import if previously unavailable
    if not _HAS_CNN or cnn_predict_skin_type is None:
        try:
            from models.predictor import predict_skin_type as cnn_predict_skin_type
            _HAS_CNN = True
        except Exception as e:
            raise RuntimeError('CNN model not available: ' + str(e))

    label, probs = cnn_predict_skin_type(image_path)
    return label, probs


def load_products():
    df = pd.read_csv(PRODUCT_CSV)
    # Normalize columns
    df['ingredients'] = df['ingredients'].fillna('')
    df['skin_types'] = df['skin_types'].fillna('')
    # Ensure optional URL/image columns exist and are strings
    if 'url' not in df.columns:
        df['url'] = ''
    else:
        df['url'] = df['url'].fillna('')
    if 'image_url' not in df.columns:
        df['image_url'] = ''
    else:
        df['image_url'] = df['image_url'].fillna('')
    return df


def recommend_products(skin_type, allergies, top_k=5):
    df = load_products()
    allergies = [a.strip().lower() for a in allergies if a.strip()]

    def is_safe(ing_text):
        low = ing_text.lower()
        for a in allergies:
            if a and a in low:
                return False
        return True

    # Filter by safe ingredients
    df['safe'] = df['ingredients'].apply(is_safe)
    df_safe = df[df['safe']]

    # Score by whether skin_type appears in product skin_types (content-based)
    def score_row(row):
        types = [t.strip().lower() for t in row['skin_types'].split(',') if t.strip()]
        score = 0
        if skin_type in types:
            score += 2
        # penalize products with many potentially irritating ingredients (simple heuristic)
        irr = ['fragrance', 'alcohol', 'menthol', 'peppermint']
        low = row['ingredients'].lower()
        for i in irr:
            if i in low:
                score -= 1
        return score

    df_safe['score'] = df_safe.apply(score_row, axis=1)
    df_safe = df_safe.sort_values(['score', 'rating'], ascending=[False, False])

    recs = df_safe.head(top_k).to_dict(orient='records')
    return recs


@app.route('/', methods=['GET', 'POST'])
def index():
    # initialize locals so GET requests won't hit UnboundLocalError in error traces
    age = None
    allergies = []
    habits = None
    detected_skin = None
    recs = []
    explanations = []
    model_used = False
    probs = None
    model_error = None

    if request.method == 'POST':
        # Survey fields
        age = request.form.get('age')
        allergies_raw = request.form.get('allergies', '')
        allergies = [a.strip() for a in allergies_raw.split(',') if a.strip()]
        habits = request.form.get('habits', '')

        # Handle image
        f = request.files.get('image')
        if not f:
            return render_template('index.html', error='Please upload an image and try again.')
        filename = os.path.join(app.config['UPLOAD_FOLDER'], f.filename)
        f.save(filename)

        # Validate that the uploaded image contains a face or visible skin region
        if not contains_face_or_skin(filename):
            # remove saved file to avoid clutter
            try:
                os.remove(filename)
            except Exception:
                pass
            return render_template('index.html', error='Skin not found: the uploaded image does not appear to contain a face or visible skin. Please upload a clear frontal face image.')

        # Model mode selection (auto / force_model / force_heuristic)
        model_mode = request.form.get('model_mode', 'auto')
        model_used = False
        probs = None
        model_error = None

        if model_mode == 'force_heuristic':
            detected_skin = detect_skin_type(filename)
            model_used = False
        elif model_mode == 'force_model':
            try:
                detected_skin, probs = detect_skin_type_with_model(filename)
                model_used = True
            except Exception as e:
                model_error = str(e)
                # fall back to heuristic but note model not used
                detected_skin = detect_skin_type(filename)
                model_used = False
        else:  # auto
            try:
                detected_skin, probs = detect_skin_type_with_model(filename)
                model_used = True
            except Exception:
                detected_skin = detect_skin_type(filename)
                model_used = False

        recs = recommend_products(detected_skin, allergies, top_k=5)

        # Build explanations
        explanations = []
        for r in recs:
            reason = []
            reason.append(f"Matches detected skin type: {detected_skin}")
            if allergies:
                reason.append('Does not contain listed allergens')
            # if product highly rated
            if r.get('rating', 0) >= 4.0:
                reason.append('Highly rated by other users')
            explanations.append('; '.join(reason))

        return render_template('result.html', age=age, habits=habits, allergies=allergies,
                               detected_skin=detected_skin, recs=recs, explanations=explanations,
                               model_used=model_used, probs=probs, model_error=model_error)
    # GET
    return render_template('index.html')


@app.route('/evaluation')
def evaluation():
    report_text = None
    image_exists = False
    try:
        if os.path.exists(EVAL_REPORT):
            with open(EVAL_REPORT, 'r', encoding='utf-8') as f:
                report_text = f.read()
        image_exists = os.path.exists(EVAL_IMAGE)
    except Exception:
        report_text = None
        image_exists = False
    return render_template('evaluation.html', report=report_text, image_exists=image_exists)


@app.route('/evaluation/image')
def evaluation_image():
    """Serve the generated confusion matrix image from the models folder.

    This keeps evaluation artifacts in the repo root while allowing the
    template to request the image via a normal URL.
    """
    try:
        if os.path.exists(EVAL_IMAGE):
            return send_file(EVAL_IMAGE, mimetype='image/png')
    except Exception:
        pass
    return ('', 404)


if __name__ == '__main__':
    app.run(debug=True)
