"""
Evaluate trained skin-type model on validation set.
Saves `models/eval_report.txt` and `models/confusion_matrix.png`.
"""
import os
from pathlib import Path
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

MODEL_PATH = Path(__file__).parent / 'skin_model.h5'
VAL_DIR = Path('data') / 'val'
OUT_DIR = Path(__file__).parent


def main():
    if not MODEL_PATH.exists():
        raise RuntimeError(f'Model file not found at {MODEL_PATH}')

    model = load_model(str(MODEL_PATH))

    val_gen = ImageDataGenerator(rescale=1./255)
    flow = val_gen.flow_from_directory(
        str(VAL_DIR),
        target_size=(224, 224),
        batch_size=8,
        class_mode='categorical',
        shuffle=False
    )

    print('Running predictions on validation set...')
    preds = model.predict(flow, verbose=1)
    y_pred = np.argmax(preds, axis=1)
    y_true = flow.classes
    class_indices = flow.class_indices
    inv_map = {v: k for k, v in class_indices.items()}
    labels = [inv_map[i] for i in sorted(inv_map.keys())]

    report = classification_report(y_true, y_pred, target_names=labels)
    cm = confusion_matrix(y_true, y_pred)

    # Save textual report
    (OUT_DIR / 'eval_report.txt').write_text(report)
    print('\nClassification report:\n')
    print(report)

    # Plot confusion matrix
    plt.figure(figsize=(6,6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix')
    plt.tight_layout()
    plt.savefig(OUT_DIR / 'confusion_matrix.png')
    print(f'Confusion matrix saved to {OUT_DIR / "confusion_matrix.png"}')


if __name__ == '__main__':
    main()
