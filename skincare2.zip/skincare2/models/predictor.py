"""
Lightweight wrapper that loads a trained Keras model (if present)
and exposes `predict_skin_type(image_path)` which returns one of:
'oily','dry','normal','combination'.

If no model is available or loading fails, functions will raise an ImportError/RuntimeError to allow fallback.
"""
import os

from PIL import Image
import numpy as np

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'skin_model.h5')
# Default class names; will attempt to infer from `data/train` if available.
DEFAULT_CLASS_NAMES = ['oily', 'dry', 'normal', 'combination']

def infer_class_names():
    # Try to infer class names from data/train directory if present
    data_train = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'train')
    if os.path.isdir(data_train):
        try:
            classes = sorted([d for d in os.listdir(data_train) if os.path.isdir(os.path.join(data_train, d))])
            if classes:
                return classes
        except Exception:
            pass
    return DEFAULT_CLASS_NAMES

_model = None


def load_model(path=None):
    global _model
    if _model is not None:
        return _model
    try:
        from tensorflow.keras.models import load_model
    except Exception as e:
        raise ImportError('TensorFlow/Keras not available: ' + str(e))

    p = path or MODEL_PATH
    if not os.path.exists(p):
        raise RuntimeError(f'Model file not found at {p}')
    _model = load_model(p)
    return _model


def preprocess_image(image_path):
    img = Image.open(image_path).convert('RGB')
    img = img.resize((224, 224))
    arr = np.asarray(img).astype('float32') / 255.0
    arr = np.expand_dims(arr, axis=0)
    return arr


def predict_skin_type(image_path):
    """Return predicted class label string and softmax probabilities dict."""
    model = load_model()
    x = preprocess_image(image_path)
    probs = model.predict(x)[0]
    # Determine class names for this model. If the model output size
    # differs from our default list, use the first N inferred class
    # names to map probabilities safely.
    class_names = infer_class_names()
    n_out = int(probs.shape[0])
    if len(class_names) < n_out:
        # fall back to defaults trimmed/extended as needed
        class_names = DEFAULT_CLASS_NAMES[:n_out]
    else:
        class_names = class_names[:n_out]

    idx = int(np.argmax(probs))
    label = class_names[idx]

    # Build probability map safely for available outputs
    prob_map = {class_names[i]: float(probs[i]) for i in range(n_out)}
    return label, prob_map
