"""
Training script for skin-type classifier.

Usage example (when you have data arranged as):
data/train/<class>/*.jpg
data/val/<class>/*.jpg

python models/train_skin_cnn.py --train_dir data/train --val_dir data/val --epochs 5 --batch_size 16 --output models/skin_model.h5

Classes expected: 'oily','dry','normal','combination' (directory names)
"""
import argparse
import os

import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras import layers, models, optimizers


def build_model(num_classes):
    base = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
    base.trainable = False  # transfer learning: freeze base

    model = models.Sequential([
        base,
        layers.GlobalAveragePooling2D(),
        layers.Dropout(0.3),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.2),
        layers.Dense(num_classes, activation='softmax')
    ])
    return model


def main(args):
    train_dir = args.train_dir
    val_dir = args.val_dir
    epochs = args.epochs
    batch_size = args.batch_size
    out_path = args.output

    # If classes are provided via CLI, use them. Otherwise infer from train_dir subfolders.
    if args.classes:
        classes = [c.strip() for c in args.classes.split(',') if c.strip()]
    else:
        # infer classes from subdirectories in train_dir
        classes = sorted([d for d in os.listdir(train_dir) if os.path.isdir(os.path.join(train_dir, d))])
        if not classes:
            raise RuntimeError(f'No class subdirectories found in {train_dir}. Provide --classes or arrange data/train/<class>/')

    train_gen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=15,
        width_shift_range=0.1,
        height_shift_range=0.1,
        horizontal_flip=True,
        brightness_range=(0.8, 1.2)
    )

    val_gen = ImageDataGenerator(rescale=1./255)

    train_flow = train_gen.flow_from_directory(
        train_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        classes=classes,
        class_mode='categorical'
    )

    val_flow = val_gen.flow_from_directory(
        val_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        classes=classes,
        class_mode='categorical'
    )

    model = build_model(len(classes))
    model.compile(optimizer=optimizers.Adam(learning_rate=1e-4),
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(out_path, save_best_only=True, monitor='val_accuracy'),
        tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
    ]

    history = model.fit(
        train_flow,
        validation_data=val_flow,
        epochs=epochs,
        callbacks=callbacks
    )

    print(f"Training complete. Best model saved to {out_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_dir', required=True, help='Path to training directory (with class subfolders)')
    parser.add_argument('--val_dir', required=True, help='Path to validation directory (with class subfolders)')
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--output', default='models/skin_model.h5')
    parser.add_argument('--classes', help='Optional comma-separated class names, e.g. oily,dry')
    args = parser.parse_args()
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    main(args)
