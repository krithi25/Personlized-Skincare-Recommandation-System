"""
Generate a small synthetic dataset for quick experiments.
Creates folders:
  data/train/oily, data/train/dry, data/train/normal, data/train/combination
  data/val/... (same classes)

Each image is 224x224 JPG with simple brightness/noise patterns that differ per class.
This is only for prototyping and fast testing of the training pipeline.
"""
import os
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

ROOT = os.path.join(os.path.dirname(__file__), '..')
DATA_DIR = os.path.abspath(os.path.join(ROOT, 'data'))

CLASSES = ['oily', 'dry', 'normal', 'combination']
TRAIN_PER_CLASS = 30
VAL_PER_CLASS = 10
SIZE = (224, 224)

os.makedirs(DATA_DIR, exist_ok=True)


def make_oily(img):
    # bright base with glossy highlight
    base = Image.new('RGB', SIZE, (220, 200, 190))
    draw = ImageDraw.Draw(base)
    # glossy circular highlight
    draw.ellipse((SIZE[0]*0.25, SIZE[1]*0.05, SIZE[0]*0.85, SIZE[1]*0.45), fill=(255,255,230))
    # slight blur to simulate sheen
    return base.filter(ImageFilter.GaussianBlur(radius=2))


def make_dry(img):
    # matte darker base with fine noise
    base = Image.new('RGB', SIZE, (180, 160, 150))
    arr = np.array(base).astype(np.int16)
    noise = np.random.randint(-25, 25, (SIZE[1], SIZE[0], 3))
    arr = np.clip(arr + noise, 0, 255).astype('uint8')
    return Image.fromarray(arr)


def make_normal(img):
    # balanced medium-tone
    base = Image.new('RGB', SIZE, (200, 185, 175))
    # add subtle texture
    draw = ImageDraw.Draw(base)
    for i in range(80):
        x = np.random.randint(0, SIZE[0])
        y = np.random.randint(0, SIZE[1])
        r = np.random.randint(1,4)
        color = (np.random.randint(190,220),)*3
        draw.ellipse((x-r,y-r,x+r,y+r), fill=color)
    return base.filter(ImageFilter.GaussianBlur(radius=0.5))


def make_combination(img):
    # left half oily, right half dry
    left = make_oily(img)
    right = make_dry(img)
    combined = Image.new('RGB', SIZE)
    combined.paste(left.crop((0,0,SIZE[0]//2, SIZE[1])), (0,0))
    combined.paste(right.crop((SIZE[0]//2,0,SIZE[0], SIZE[1])), (SIZE[0]//2,0))
    return combined

GEN_FUNCS = {
    'oily': make_oily,
    'dry': make_dry,
    'normal': make_normal,
    'combination': make_combination
}


def ensure_dirs():
    for split in ['train', 'val']:
        for c in CLASSES:
            d = os.path.join(DATA_DIR, split, c)
            os.makedirs(d, exist_ok=True)


def generate():
    ensure_dirs()
    # train
    for c in CLASSES:
        d = os.path.join(DATA_DIR, 'train', c)
        for i in range(TRAIN_PER_CLASS):
            img = Image.new('RGB', SIZE)
            img = GEN_FUNCS[c](img)
            path = os.path.join(d, f'{c}_{i:03d}.jpg')
            img.save(path, quality=90)
    # val
    for c in CLASSES:
        d = os.path.join(DATA_DIR, 'val', c)
        for i in range(VAL_PER_CLASS):
            img = Image.new('RGB', SIZE)
            img = GEN_FUNCS[c](img)
            path = os.path.join(d, f'{c}_val_{i:03d}.jpg')
            img.save(path, quality=90)

    print('Synthetic dataset created under', DATA_DIR)


if __name__ == '__main__':
    generate()
