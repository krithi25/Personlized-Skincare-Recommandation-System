"""
Prepare the Oily-Dry-Skin-Types dataset (or any similar dataset) into
`data/train/<class>` and `data/val/<class>` folders for training.

Usage examples:

# If the dataset is already organized into subfolders per class:
python scripts/prepare_oily_dry_dataset.py --src /path/to/Oily-Dry-Skin-Types --out data --val_frac 0.2

# If the dataset is flat and filenames contain labels like 'image_oily_001.jpg' or 'dry_image_1.jpg':
python scripts/prepare_oily_dry_dataset.py --src /path/to/images --out data --val_frac 0.2 --label_keywords oily:OILY dry:DRY

This script will create `data/train/<class>` and `data/val/<class>`.
"""
import argparse
import os
import shutil
import random
from pathlib import Path


def split_and_copy(files, dest_dir, val_frac=0.2):
    random.shuffle(files)
    n_val = max(1, int(len(files) * val_frac))
    val_files = files[:n_val]
    train_files = files[n_val:]
    for f in train_files:
        shutil.copy(f, dest_dir / 'train' / dest_dir.name)
    for f in val_files:
        shutil.copy(f, dest_dir / 'val' / dest_dir.name)


def prepare_from_subdirs(src, out_dir, val_frac=0.2):
    src = Path(src)
    out_dir = Path(out_dir)
    # Detect common dataset layouts. If the source contains top-level
    # split folders like `train/` and `valid/`, treat those as splits and
    # copy accordingly. Otherwise treat each top-level folder as a class
    # and perform an internal split by `val_frac`.
    top_dirs = [d.name.lower() for d in src.iterdir() if d.is_dir()]
    has_splits = any(d in ('train', 'valid', 'test') for d in top_dirs)

    if has_splits:
        train_src = src / 'train'
        valid_src = src / 'valid'

        # Collect classes from train/ and valid/ subfolders
        classes = []
        if train_src.exists():
            classes += [d.name for d in train_src.iterdir() if d.is_dir()]
        if valid_src.exists():
            for d in valid_src.iterdir():
                if d.is_dir() and d.name not in classes:
                    classes.append(d.name)

        for cls in classes:
            train_cls = out_dir / 'train' / cls
            val_cls = out_dir / 'val' / cls
            train_cls.mkdir(parents=True, exist_ok=True)
            val_cls.mkdir(parents=True, exist_ok=True)

            # Copy train images
            if train_src.exists():
                src_dir = train_src / cls
                if src_dir.exists():
                    for p in src_dir.glob('*'):
                        if p.suffix.lower() in ('.jpg', '.jpeg', '.png'):
                            shutil.copy(p, train_cls / p.name)

            # If a valid/ split exists for this class, use it as the val set.
            if valid_src.exists():
                vdir = valid_src / cls
                if vdir.exists():
                    for p in vdir.glob('*'):
                        if p.suffix.lower() in ('.jpg', '.jpeg', '.png'):
                            shutil.copy(p, val_cls / p.name)
            else:
                # Otherwise, split the copied train images to create a val set
                files = [p for p in (train_src / cls).glob('*') if p.suffix.lower() in ('.jpg', '.jpeg', '.png')] if train_src.exists() else []
                if files:
                    random.shuffle(files)
                    n_val = max(1, int(len(files) * val_frac))
                    for i, p in enumerate(files):
                        if i < n_val:
                            shutil.copy(p, val_cls / p.name)

        print(f'Prepared data in {out_dir}/train and {out_dir}/val (from split folders)')
        return

    # Fallback: each top-level folder is a class
    for cls in [d.name for d in src.iterdir() if d.is_dir()]:
        src_cls = src / cls
        train_cls = out_dir / 'train' / cls
        val_cls = out_dir / 'val' / cls
        train_cls.mkdir(parents=True, exist_ok=True)
        val_cls.mkdir(parents=True, exist_ok=True)
        files = [p for p in src_cls.glob('**/*') if p.suffix.lower() in ['.jpg', '.jpeg', '.png']]
        random.shuffle(files)
        n_val = max(1, int(len(files) * val_frac))
        for i, p in enumerate(files):
            if i < n_val:
                shutil.copy(p, val_cls / p.name)
            else:
                shutil.copy(p, train_cls / p.name)
    print(f'Prepared data in {out_dir}/train and {out_dir}/val')


def prepare_from_filenames(src, out_dir, keywords_map, val_frac=0.2):
    src = Path(src)
    out_dir = Path(out_dir)
    files = [p for p in src.glob('**/*') if p.suffix.lower() in ['.jpg', '.jpeg', '.png']]
    class_files = {cls: [] for cls in set(keywords_map.values())}
    for p in files:
        name = p.name.lower()
        found = False
        for kw, cls in keywords_map.items():
            if kw.lower() in name:
                class_files[cls].append(p)
                found = True
                break
        if not found:
            # could put into 'unknown' or skip
            pass
    for cls, flist in class_files.items():
        train_cls = out_dir / 'train' / cls
        val_cls = out_dir / 'val' / cls
        train_cls.mkdir(parents=True, exist_ok=True)
        val_cls.mkdir(parents=True, exist_ok=True)
        random.shuffle(flist)
        n_val = max(1, int(len(flist) * val_frac))
        for i, p in enumerate(flist):
            if i < n_val:
                shutil.copy(p, val_cls / p.name)
            else:
                shutil.copy(p, train_cls / p.name)
    print(f'Prepared data in {out_dir}/train and {out_dir}/val')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--src', required=True, help='Source dataset folder (subfolders per class or flat).')
    parser.add_argument('--out', default='data', help='Output base folder (will create train/ and val/ under this).')
    parser.add_argument('--val_frac', type=float, default=0.2)
    parser.add_argument('--label_keywords', nargs='*', help='Optional mapping keywords like oily:OILY dry:DRY (format key:CLASS).')
    args = parser.parse_args()

    random.seed(42)

    src = Path(args.src)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    if any(p.is_dir() for p in src.iterdir()):
        # If there are subdirectories, use them as classes
        prepare_from_subdirs(src, out, val_frac=args.val_frac)
    elif args.label_keywords:
        mapping = {}
        for item in args.label_keywords:
            if ':' in item:
                k, v = item.split(':', 1)
                mapping[k] = v
        prepare_from_filenames(src, out, mapping, val_frac=args.val_frac)
    else:
        raise RuntimeError('Source folder has no subdirectories. Provide --label_keywords for flat datasets.')
